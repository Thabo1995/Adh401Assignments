package controller;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import model.Transaction;

@ManagedBean(name ="transactioncontroller")
@SessionScoped
public class transactionController {
	
	@ManagedProperty(value="#{transaction}")
	private Transaction transaction;
	
	public void addNewTransaction()
	{
		System.out.println("****transaction loading******");
	}

}
